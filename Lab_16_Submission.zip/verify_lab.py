"""Reproduce the assignment's known-answer and later-date checks."""
from contextlib import redirect_stdout
from io import StringIO
from math import isclose

import asof


def main():
    panel, naive, audit = asof.provenance_gate(asof.TABLE, "2026-03-31")
    assert [[r[0] for r in rows] for _, rows in audit] == [[11], [7], [3, 8, 10], [2]]
    assert [r[0] for r in panel] == [1, 4, 5, 6, 9, 12]
    for data, expected in [
        (panel, {"AAA": ("2026-02", 1.98), "BBB": ("2026-02", -1.02), "CCC": ("2026-02", 0.91)}),
        (naive, {"AAA": ("2026-03", 5.83), "BBB": ("2026-03", -5.15), "CCC": ("2026-02", 1.82)}),
    ]:
        actual = asof.signals(data)
        for ticker, (month, value) in expected.items():
            assert actual[ticker][0] == month
            assert isclose(actual[ticker][1], value, abs_tol=0.005)
    later, _, later_audit = asof.provenance_gate(asof.TABLE, "2026-04-15")
    assert asof.signals(later) == asof.signals(naive)
    assert [r[0] for r in later] == [1, 3, 4, 5, 6, 8, 9, 10]
    assert not later_audit[2][1]
    # Inclusive boundary: CCC's revised value becomes available on April 5.
    boundary, _, _ = asof.provenance_gate(asof.TABLE, "2026-04-05")
    assert 10 in [r[0] for r in boundary]
    assert 12 not in [r[0] for r in boundary]
    print("PASS: March 31 funnel, panel, all six rounded signals.")
    print("PASS: April 15 as-of signals equal naive signals for every ticker.")
    print("PASS: Publication on the cutoff date is included.")
    original = asof.DECISION_DATE
    try:
        for cutoff in [original, "2026-04-15"]:
            asof.DECISION_DATE = cutoff
            output = StringIO()
            with redirect_stdout(output):
                asof.main()
            print("\n" + output.getvalue(), end="")
    finally:
        asof.DECISION_DATE = original


if __name__ == "__main__":
    main()
