# Lab 16 — Provenance Gate

The point-in-time filter matches the supplied known answer. On March 31, 2026, the available signals are AAA **+1.98%**, BBB **−1.02%**, and CCC **+0.91%**, all for February. Moving the decision date to April 15 makes every as-of signal equal its naive counterpart. Timely data can still contain economic errors: four of the six admitted rows fail the lab's sanity criteria.

## D — Decision question

> On the day you would have traded, what did this data actually say — and how much of what you see now came later?

The decision date is March 31, 2026. The objective is to reconstruct available information, retain source row numbers, and compare it with a calculation that uses later publications. This is a fictional training table, not market data or an investment recommendation.

The month measured describes the period a number represents. The publication date describes when that particular version became available. February's AAA value of 104 was published March 10; its revised value of 103 was published March 25. Both describe February, but March 31's information set uses 103. March's AAA value was not published until April 10.

## R and I — Data, implementation, and reproduction

Source: the 12-row training table and instructions supplied in the Lab 16 assignment. All prices and dates are copied into the editable inputs at the top of `asof.py`. No external data, API key, package installation, or network request is needed. The program calculates answers from those inputs; the supplied answers appear only in the verification script as independent expectations.

From this folder, run:

```powershell
python asof.py
python verify_lab.py
```

`verification.txt` records the verification results and both date runs. The main program remains set to `2026-03-31`.

The four rules run in the prescribed order. Missing tickers are quarantined. Exact duplicates are identified using ticker, month, publication date, and price; the source row number is excluded from the duplicate key, so row 7 duplicates row 6. The first occurrence is retained. Future publications are excluded using an inclusive decision-date cutoff. Finally, one latest eligible publication is retained for each ticker and month. Removed records remain available in the audit output returned by the function.

The naive comparison uses the same ticker and duplicate cleanup, but skips the publication cutoff before selecting each month's latest publication. A signal is `(latest price / previous calendar month's price − 1) × 100`. Missing previous months or zero starting prices produce N/A, rather than an invented return. These are the assignment's price-change signals, not a strategy backtest or annualized returns.

## V — Known-answer proof

| Step | Count excluded | Source rows | Remaining |
|---|---:|---|---:|
| Input | — | 1–12 | 12 |
| Quarantined: no ticker | 1 | 11 | 11 |
| Exact duplicate | 1 | 7 | 10 |
| Published after March 31 | 3 | 3, 8, 10 | 7 |
| Older vintage replaced | 1 | 2 | 6 |

The reconciliation is **12 = 1 quarantined + 1 duplicate + 3 future + 1 superseded + 6 admitted**. Each excluded row belongs to its first applicable rule.

| Source row | Ticker | Month measured | Published on | Price per 100 face |
|---:|---|---|---|---:|
| 1 | AAA | 2026-01 | 2026-02-10 | 101.0 |
| 4 | AAA | 2026-02 | 2026-03-25 | 103.0 |
| 5 | BBB | 2026-01 | 2026-02-10 | 98.0 |
| 6 | BBB | 2026-02 | 2026-03-10 | 97.0 |
| 9 | CCC | 2026-01 | 2026-02-10 | 110.0 |
| 12 | CCC | 2026-02 | 2026-03-10 | 111.0 |

| Ticker | As-of calculation | As-of signal | Naive calculation | Naive signal |
|---|---|---|---|---|
| AAA | (103 / 101 − 1) × 100 | +1.98%, February | (109 / 103 − 1) × 100 | +5.83%, March |
| BBB | (97 / 98 − 1) × 100 | −1.02%, February | (92 / 97 − 1) × 100 | −5.15%, March |
| CCC | (111 / 110 − 1) × 100 | +0.91%, February | (112 / 110 − 1) × 100 | +1.82%, February revised |

AAA's naive number uses a later measured month, while CCC's uses a later revision of the same measured month. The column differences therefore reflect both delayed releases and revisions, not a uniform comparison of identical return periods.

### Sanity check, with arithmetic shown

For a one-year zero-coupon price per 100 face, yield is `(100 / price − 1) × 100`.

| Row | Fund / month | Price | Yield calculation | Yield | Breaks under the lab's assumptions |
|---:|---|---:|---|---:|---|
| 1 | AAA / Jan | 101 | (100 / 101 − 1) × 100 | −0.99% | Negative yield |
| 4 | AAA / Feb | 103 | (100 / 103 − 1) × 100 | −2.91% | Negative yield |
| 5 | BBB / Jan | 98 | (100 / 98 − 1) × 100 | +2.04% | Nothing |
| 6 | BBB / Feb | 97 | (100 / 97 − 1) × 100 | +3.09% | Nothing |
| 9 | CCC / Jan | 110 | (100 / 110 − 1) × 100 | −9.09% | Negative yield; CCC priced above AAA and BBB |
| 12 | CCC / Feb | 111 | (100 / 111 − 1) × 100 | −9.91% | Negative yield; CCC priced above AAA and BBB |

January prices are CCC 110 > AAA 101 > BBB 98; February prices are CCC 111 > AAA 103 > BBB 97. Both violate the stipulated AAA > BBB > CCC ranking. Negative yields and simple rating rankings are treated as planted errors in this controlled exercise; the ranking assumes otherwise comparable instruments. A provenance test alone makes no claim about economic validity.

## Explain rule 4 — preparation for the no-AI partner exercise

The relevant function is `latest_publications` in `asof.py`.

| Code | Explanation |
|---|---|
| `latest = {}` | Start a dictionary holding one selected record for each ticker/month pair. |
| `for row in rows:` | Inspect every eligible input record. |
| `key = (row[1], row[2])` | Group using ticker and measured month, not publication month. |
| `if key not in latest or row[3] > latest[key][3]:` | Accept the first record or a publication later than the current selection. ISO YYYY-MM-DD strings sort chronologically. |
| `latest[key] = row` | Store the complete source row, preserving its number and publication date. |
| `panel = sorted(...)` | Return selected rows in original row-number order for easy auditing. |
| `kept_ids = {...}` | Collect the retained source row identifiers. |
| `removed = [...]` | Identify the eligible rows that lost to a later publication. |
| `return panel, removed` | Return both the usable data and the superseded-row audit trail. |

For AAA February, row 2 initially fills the group. Row 4 replaces it because March 25 is later than March 10. Keeping row 2 instead would produce `(104 / 101 − 1) × 100 = +2.97%`, the assignment's classic error.

### Quiz — submitted answer and feedback

Why must rule 3 run before rule 4? Use CCC rows 10 and 12.

**Student's submitted answer:**

> Row 12 should survive: its price of 111 was published March 10, so it was available on March 31. Row 10’s price of 112 was published April 5—too late.
>
> If we selected the latest revision first, we would keep row 10 and discard row 12. Removing future publications afterward would then remove row 10 too, leaving no February CCC value.
>
> That’s why we remove future publications before selecting the latest revision.

**AI feedback:** Correct. The answer identifies both the eligible row and the loss of a valid observation if the rules are reversed.

**Sequence note:** This answer was submitted after the AI explanation was provided. It records the reviewed answer; it does not establish the assignment's requested answer-before-explanation sequence.

<details>
<summary>Supporting explanation</summary>

Row 10 is a February revision published April 5, after the March 31 cutoff. Row 12 was published March 10 and is knowable. Filtering future publications first removes row 10 so row 12 survives. Selecting the newest record first would select row 10 and discard row 12; subsequently removing row 10 would incorrectly leave no February CCC observation.

</details>

Suggested partner question: “Does a publication on March 31 count?” Yes: rule 3 uses `<= cutoff`. A separate verification checks inclusion on an exact publication date.

## Swap and break — reproducible later-date check

Changing `DECISION_DATE` to `2026-04-15` admits all publications in this table. Rule 3 removes no rows; rule 4 removes rows 2 and 12. The retained panel is **1, 3, 4, 5, 6, 8, 9, 10**. Its signals are AAA **+5.83% (March)**, BBB **−5.15% (March)**, CCC **+1.82% (February)**, exactly equal to the naive signals.

The verification script runs this date change in memory and restores the original setting. To do the assigned manual exercise, run your partner's file, change its editable date, run again, compare, and undo the change. The automated check establishes the expected behavior; it does not document a partner session.

## Point-in-time — Learn on your own

1. **What is look-ahead bias?** It is using information in a historical decision that was unavailable when that decision would have been made. It gives a backtest hindsight.
2. **How does it work?** Event or observation time identifies the period measured. Publication time determines initial availability. Revision time determines when a changed historical value became available. A valid historical information set admits only publications available at that cutoff and uses the latest eligible vintage for each observation.
3. **Why does AAA's +5.83% look better?** It measures the rise from February's revised 103 to March's 109. The 109 was released April 10, so no March 31 decision could use it. The latest knowable change was January 101 to February 103, only +1.98%. Using +5.83% on March 31 gives the model access to a future release.

## Reflect

1. **Which rule mattered most?** Rule 3 is the main defense against future information: it excludes rows 3, 8, and 10. Row 3 is especially visible because it creates AAA's attractive naive March signal. Rule 4 also materially matters: it removes row 2 so the as-of calculation incorporates the already-published revision in row 4.
2. **What would a naive backtest claim?** It would treat AAA +5.83%, BBB −5.15%, and CCC +1.82% as available historical signals, despite their reliance on releases after March 31. A strategy could appear to anticipate later moves because it is reading later information. These signals alone do not establish portfolio performance or prove that every biased strategy's returns increase.
3. **What fifth rule would quarantine rows 1, 4, 9, and 12?** Under the lab's economic assumptions, quarantine nonpositive prices or prices above 100, then flag violations of AAA > BBB > CCC within the same month and maturity. The above-100 check alone identifies exactly those four admitted rows. Credit-order checks also flag CCC rows 9 and 12 for review. Keep row numbers and reasons; do not silently repair data. This sanity gate follows the provenance gate and is deliberately not applied to the six-row known-answer panel.

## Submission and remaining live activities

Upload `asof.py`, this Markdown file, `verify_lab.py`, and `verification.txt` to GitHub, then submit their GitHub file links. No repository URL is invented here; links can be copied after upload.

The code, calculations, written responses, and automated date-change check are complete. The student's quiz answer and AI feedback are recorded above, with the actual sequence noted. The student must still explain rule 4 without AI and perform the actual two-person explain/swap exercise. No partner participation has been fabricated.
