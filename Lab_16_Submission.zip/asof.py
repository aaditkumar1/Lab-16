"""Lab 16: a point-in-time provenance gate. Standard library only."""

# EDITABLE INPUTS: row number, ticker, month measured, published on, price.
DECISION_DATE = "2026-03-31"
TABLE = [
    (1, "AAA", "2026-01", "2026-02-10", 101.0),
    (2, "AAA", "2026-02", "2026-03-10", 104.0),
    (3, "AAA", "2026-03", "2026-04-10", 109.0),
    (4, "AAA", "2026-02", "2026-03-25", 103.0),
    (5, "BBB", "2026-01", "2026-02-10", 98.0),
    (6, "BBB", "2026-02", "2026-03-10", 97.0),
    (7, "BBB", "2026-02", "2026-03-10", 97.0),
    (8, "BBB", "2026-03", "2026-04-10", 92.0),
    (9, "CCC", "2026-01", "2026-02-10", 110.0),
    (10, "CCC", "2026-02", "2026-04-05", 112.0),
    (11, "", "2026-02", "2026-03-10", 99.0),
    (12, "CCC", "2026-02", "2026-03-10", 111.0),
]

from datetime import date


def latest_publications(rows):
    """Rule 4: caller must first exclude publications after the cutoff."""
    latest = {}
    for row in rows:
        key = (row[1], row[2])  # One group per ticker and measured month.
        if key not in latest or row[3] > latest[key][3]:
            latest[key] = row  # Replace only with a later publication.
    panel = sorted(latest.values(), key=lambda row: row[0])
    kept_ids = {row[0] for row in panel}
    removed = [row for row in rows if row[0] not in kept_ids]
    return panel, removed


def provenance_gate(table, decision_date):
    cutoff = date.fromisoformat(decision_date)
    rows = list(table)
    if len({row[0] for row in rows}) != len(rows):
        raise ValueError("Source row numbers must be unique.")
    for row in rows:
        date.fromisoformat(row[2] + "-01")
        date.fromisoformat(row[3])

    # Rule 1: retain missing identifiers in a quarantine audit trail.
    quarantined = [row for row in rows if not row[1].strip()]
    rows = [row for row in rows if row[1].strip()]

    # Rule 2: row number is lineage, not part of the duplicate definition.
    seen, unique, duplicates = set(), [], []
    for row in rows:
        record = row[1:]
        if record in seen:
            duplicates.append(row)
        else:
            seen.add(record)
            unique.append(row)

    # Rule 3: publication on the decision date is allowed (inclusive cutoff).
    future = [row for row in unique if date.fromisoformat(row[3]) > cutoff]
    knowable = [row for row in unique if date.fromisoformat(row[3]) <= cutoff]

    # Rule 4 runs AFTER rule 3, so a future revision cannot replace a known row.
    panel, superseded = latest_publications(knowable)
    audit = [
        ("1. Quarantined: no ticker", quarantined),
        ("2. Removed: exact duplicate", duplicates),
        ("3. Removed: published after decision date", future),
        ("4. Removed: older vintage replaced by revision", superseded),
    ]
    # Naive comparison still excludes missing tickers and exact duplicates.
    naive, _ = latest_publications(unique)
    return panel, naive, audit


def signals(panel):
    result = {}
    for ticker in sorted({row[1] for row in panel}):
        history = sorted((row for row in panel if row[1] == ticker),
                         key=lambda row: row[2])
        latest = history[-1]
        year, month = map(int, latest[2].split("-"))
        previous_month = f"{year - (month == 1):04d}-{(month - 2) % 12 + 1:02d}"
        previous = next((row for row in history if row[2] == previous_month), None)
        change = None
        if previous is not None and previous[4] != 0:
            change = (latest[4] / previous[4] - 1) * 100
        result[ticker] = (latest[2], change)
    return result


def main():
    panel, naive, audit = provenance_gate(TABLE, DECISION_DATE)
    print(f"Lab 16 - Provenance Gate | Decision date: {DECISION_DATE}")
    print(f"\nROW FUNNEL | Input: {len(TABLE)} rows")
    remaining = len(TABLE)
    for label, removed in audit:
        remaining -= len(removed)
        ids = ", ".join(str(row[0]) for row in removed) or "none"
        print(f"{label}: {len(removed)} rows [{ids}]; remaining {remaining}")
    print(f"As-of panel: {len(panel)} rows [{', '.join(str(r[0]) for r in panel)}]")
    print("\nAS-OF PANEL\nRow  Ticker  Month    Published    Price")
    for number, ticker, month, published, price in panel:
        print(f"{number:>3}  {ticker:<6}  {month}  {published}  {price:>6.1f}")
    for label, data in [("AS-OF SIGNALS", panel), ("NAIVE SIGNALS", naive)]:
        print(f"\n{label}")
        for ticker, (month, change) in signals(data).items():
            value = "N/A (missing previous month or zero starting price)" if change is None else f"{change:+.2f}%"
            print(f"{ticker}: {value} ({month})")


if __name__ == "__main__":
    main()
